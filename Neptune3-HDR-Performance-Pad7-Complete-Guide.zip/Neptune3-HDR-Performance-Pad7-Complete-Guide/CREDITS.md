# HDR Performance

**Neptune 3 Robin Nano + BTT Pad 7 upgrade package by HDR Performance.**

Package integration, organized workflows, safety-oriented macros, adaptive
meshing and purge configuration, filament handling, persistent material
profiles, Z-offset workflow, heat-soak controls, and maintenance features are
credited to HDR Performance.

This package builds on Klipper and Klipper Adaptive Meshing & Purging (KAMP).
Those upstream projects retain their respective authorship and licenses.
