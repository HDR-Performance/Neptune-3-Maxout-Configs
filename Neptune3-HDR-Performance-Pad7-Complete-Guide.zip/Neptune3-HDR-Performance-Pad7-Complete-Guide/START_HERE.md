# Neptune 3 installation and usage guide

HDR Performance package for the standard Elegoo Neptune 3 with a Robin Nano
controller and BTT Pad 7. Do not install this package on a Pro, Plus, or Max.

## 1. Back up the printer

1. In Mainsail, open **Machine**.
2. Download a complete configuration backup before replacing anything.
3. Keep copies of `printer.cfg`, `moonraker.conf`, `mainsail.cfg`,
   `KlipperScreen.conf`, `timelapse.cfg`, and the existing `KAMP/` directory.
4. Make sure this is the standard Neptune 3 with the Robin Nano board.

## 2. Check the BTT Pad 7 accelerometer

This package expects the Pad 7 host MCU at `/tmp/klipper_host_mcu` and its
ADXL345 on `spidev1.1`. These settings match the HDR Performance Maxout setup.
If the host MCU is not installed, Klipper will report that the `CB1` MCU cannot
connect. Restore the backup and finish the Pad 7 host-MCU setup before
continuing.

## 3. Copy the package

1. Open the ZIP and then its `config` folder.
2. In Mainsail **Machine**, open the active `/config` directory.
3. Upload the **contents** of the packaged `config` folder, not the outer ZIP
   folder.
4. Allow `printer.cfg` and `KAMP_Settings.cfg` to be replaced.
5. Upload the complete `custom/` folder while preserving its subfolders.
6. Do not replace host files such as `moonraker.conf` or the updater-managed
   `KAMP/` directory.
7. Select **Save & Restart**. Do not move or heat the printer if Klipper shows
   an error.

## 4. Required KAMP and slicer settings

Moonraker needs object processing enabled:

```ini
[file_manager]
enable_object_processing: True
```

In OrcaSlicer, enable **Label objects**. Use this machine start G-code:

```gcode
M117
START_PRINT BED_TEMP=[bed_temperature_initial_layer_single] EXTRUDER_TEMP=[nozzle_temperature_initial_layer] MATERIAL=PETG
```

Change `MATERIAL` to `PLA`, `PETG`, or `TPU` for the selected filament. Use
this machine end G-code:

```gcode
END_PRINT
```

Remove slicer-generated `G28`, bed-mesh, and purge-line commands when they
duplicate `START_PRINT`.

## 5. Safe first test

Keep a hand near Emergency Stop during these tests.

1. Run `HDR_PACKAGE_INFO` and confirm it identifies the Neptune 3 package.
2. Check that room-temperature heater readings look reasonable.
3. Run `G28`. The strain-gauge probe should tare briefly, and safe Z homing
   should occur near X110 Y110.
4. Run `SMART_PARK`; Z must lift before XY travel.
5. Heat the nozzle and run `LINE_PURGE`; the purge must remain on the bed.
6. Run `ACCELEROMETER_QUERY`. Continue only if live acceleration values appear.
7. Print a small model near the center with `SOAK_MINUTES=0`.

## 6. Calibrate input shaper

Secure the Pad 7 accelerometer firmly to the toolhead. Run:

```gcode
CALIBRATE_SHAPER
```

The printer homes, measures both axes at X110 Y110 Z20, saves the recommended
values, and restarts Klipper. Never run this during a print, and keep tools,
cables, and hands clear while the axes vibrate.

## 7. Set the Z offset

Run `MANUAL_Z_OFFSET_ADJUST TEMP=230 PURGE_AMOUNT=30`. The macro keeps the bed
heater off, homes, heats and cleans the nozzle on the left, switches the nozzle
heater off, returns to X110 Y110, and opens the Mainsail TESTZ controls.

Use paper and the TESTZ buttons, select **ACCEPT**, then run `SAVE_CONFIG`.
Klipper restarts and uses the newly saved value during the next calibration.

## 8. Everyday controls

- `SET_MATERIAL MATERIAL=PETG`: select a persistent material profile.
- `LOAD_FILAMENT`: heat, load, purge, and cool down.
- `UNLOAD_FILAMENT`: heat, form a tip, unload, and cool down.
- `M600`: start a guided color change during a print.
- `RUNOUT_RESUME`: load replacement filament and resume after runout or M600.
- `TOGGLE_HEAT_SOAK`: toggle the saved five-minute pre-mesh heat soak.
- `HEAT_SOAK_STATUS`: show whether automatic heat soak is enabled.
- `G29`: home and create a runtime adaptive mesh.
- `M420`: manually load the saved default mesh.
- `BED_PID_TUNE TEMP=60`: tune and save the bed PID.
- `NOZZLE_PID_TUNE TEMP=230`: tune and save the hotend PID.
- `MAINTENANCE_STATUS`: display print and service counters.

The standard Neptune 3 source did not provide verified bed-screw coordinates,
so this package intentionally does not include automatic screw tramming.

## 9. Recovery

If Klipper will not start, do not move or heat the printer. Restore the backed
up `printer.cfg` and restart. The most common Pad 7-specific error is a missing
`/tmp/klipper_host_mcu` connection.

See `FEATURE_GUIDE.md` for detailed macro parameters and `CREDITS.md` for
package attribution.
