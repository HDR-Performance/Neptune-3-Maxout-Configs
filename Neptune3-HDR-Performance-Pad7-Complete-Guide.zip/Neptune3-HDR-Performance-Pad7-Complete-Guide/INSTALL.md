# HDR Performance Neptune 3 + BTT Pad 7 upgrade package

Upgrade package by **HDR Performance** for the standard **Elegoo Neptune 3**
with the **ZNP Robin Nano DW v2.2** controller and **BTT Pad 7** ADXL345.

This package uses the supplied config's 235 mm XY motion envelope, 280 mm Z
limit, strain-gauge probe with tare cycle, heater PID values, mesh bounds, and
input-shaper starting values. Do not substitute Pro probe or fan settings.

## Before copying

1. Download a fresh full configuration backup from Mainsail.
2. Do not delete or overwrite `moonraker.conf`, `KlipperScreen.conf`,
   `sonar.conf`, or any other host-service configuration.
3. Confirm the printer is the standard Neptune 3 using a Robin Nano board and
   BTT Pad 7. This package is not for a Neptune 3 Pro, Plus, Max, or SKR board.
4. Confirm `/tmp/klipper_host_mcu` exists on the Pad 7 before restarting
   Klipper. This interface is required by the included ADXL345 configuration.

## Install

Copy the **contents** of the ZIP's `config` folder into the printer's active
configuration directory. Allow it to replace `printer.cfg` and
`KAMP_Settings.cfg`. It adds the organized `custom/` directory.

The supplied source had timelapse disabled, so this package leaves the line
below commented in `printer.cfg`:

```ini
#[include timelapse.cfg]
```

Only uncomment it if `timelapse.cfg` is already installed and working.

## Required KAMP settings

Moonraker must contain:

```ini
[file_manager]
enable_object_processing: True
```

Enable **Label objects** in OrcaSlicer. Example start G-code:

```gcode
M117
START_PRINT BED_TEMP=[bed_temperature_initial_layer_single] EXTRUDER_TEMP=[nozzle_temperature_initial_layer] MATERIAL=PETG
```

Use `END_PRINT` as the end G-code. Change `MATERIAL=PETG` to PLA or TPU when
appropriate.

## First-test order

1. Select **Save & Restart**. If Klipper reports an error, do not move or heat
   the printer.
2. Run `HDR_PACKAGE_INFO` and confirm the Neptune 3 package credit is shown.
3. Home with `G28`. Safe Z homing should occur at X110 Y110. The strain-gauge
   probe should pause briefly for its tare cycle before each probe action.
4. Run `SMART_PARK`. Z must lift before XY travel, and XY is capped at
   100 mm/s.
5. Heat the nozzle and run `LINE_PURGE`. It should lay a 75 mm purge line using
   30 mm of filament, then wipe and lift.
6. Run `MANUAL_Z_OFFSET_ADJUST`; verify the left-side clean, return to X110
   Y110, and Mainsail TESTZ controls.
7. Print a small center-bed model with `SOAK_MINUTES=0` while ready to use
   Emergency Stop.

## Manual Z-offset workflow

`MANUAL_Z_OFFSET_ADJUST TEMP=230 PURGE_AMOUNT=30` keeps the bed heater off,
homes, cleans the nozzle along the left side, turns the nozzle heater off, and
immediately starts `PROBE_CALIBRATE` at the Neptune 3 safe-home position. Use the
Mainsail TESTZ controls, press **ACCEPT**, then run **SAVE_CONFIG**. The next
calibration reads the newly saved offset automatically.

## Input shaper

The supplied starting values are preserved: Y uses MZV at 38.2 Hz and X uses
EI at 79.6 Hz. The included Pad 7 configuration uses the host MCU at
`/tmp/klipper_host_mcu`, the onboard ADXL345 on `spidev1.1`, and the same
`axes_map: z,y,-x` as the HDR Performance Maxout setup.

With the accelerometer secured to the toolhead, run `ACCELEROMETER_QUERY` and
confirm values are returned. Then run `CALIBRATE_SHAPER`. It homes, calibrates
both axes, and runs `SAVE_CONFIG`. Keep clear of the printer during testing.
