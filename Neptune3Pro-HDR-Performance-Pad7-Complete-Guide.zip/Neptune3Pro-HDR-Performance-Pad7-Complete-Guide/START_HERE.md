# Neptune 3 Pro installation and usage guide

HDR Performance package for the Elegoo Neptune 3 Pro with a Robin Nano
controller and BTT Pad 7. Do not install it on the standard, Plus, or Max.

## 1. Back up and verify

1. Download a complete configuration backup from Mainsail **Machine**.
2. Preserve `printer.cfg`, all host-service files, and the existing `KAMP/`
   directory.
3. Confirm the printer is a Neptune 3 Pro with a Robin Nano board.
4. Confirm the Pad 7 host MCU exists at `/tmp/klipper_host_mcu`.

## 2. Install

1. Open the ZIP and its `config` folder.
2. Upload the **contents** of that folder into Mainsail's active `/config`
   directory.
3. Replace `printer.cfg` and `KAMP_Settings.cfg`, and upload the entire
   `custom/` folder.
4. Do not replace `moonraker.conf`, `mainsail.cfg`, `KlipperScreen.conf`,
   `timelapse.cfg`, or the updater-managed `KAMP/` directory.
5. Select **Save & Restart**. Stop if Klipper reports an error.

Moonraker must contain:

```ini
[file_manager]
enable_object_processing: True
```

## 3. Configure the slicer

Enable **Label objects** in OrcaSlicer. Machine start G-code:

```gcode
M117
START_PRINT BED_TEMP=[bed_temperature_initial_layer_single] EXTRUDER_TEMP=[nozzle_temperature_initial_layer] MATERIAL=PETG
```

Machine end G-code:

```gcode
END_PRINT
```

Set `MATERIAL` to `PLA`, `PETG`, or `TPU`. Remove duplicate slicer homing,
meshing, and purge commands because `START_PRINT` handles them.

## 4. First-test order

1. Run `HDR_PACKAGE_INFO` and confirm it identifies the Pro package.
2. Verify the displayed heater temperatures are plausible.
3. Run `G28`; safe Z homing should occur near X117.5 Y117.5.
4. Run `SMART_PARK` and confirm Z lifts before XY movement.
5. Heat the nozzle and run `LINE_PURGE`; it must remain inside the bed.
6. Run `ACCELEROMETER_QUERY` and confirm live values appear.
7. Print a small center-bed object with `SOAK_MINUTES=0`.

Keep a hand near Emergency Stop during every first physical test.

## 5. Input shaper

Fasten the Pad 7 accelerometer to the toolhead and run `CALIBRATE_SHAPER`.
It homes, measures X and Y at X117.5 Y117.5 Z20, saves the recommendations,
and restarts Klipper. Keep the printer clear while it vibrates.

## 6. Z-offset adjustment

Run:

```gcode
MANUAL_Z_OFFSET_ADJUST TEMP=230 PURGE_AMOUNT=30
```

The bed remains off. The printer homes, cleans the hot nozzle along the left
side, switches the heater off, returns to X117.5 Y117.5, and opens Mainsail's
TESTZ panel. Adjust with paper, press **ACCEPT**, then run `SAVE_CONFIG`.

## 7. Daily features

- `SET_MATERIAL MATERIAL=PETG`: select a persistent material profile.
- `LOAD_FILAMENT` and `UNLOAD_FILAMENT`: guided filament handling.
- `M600`: pause and unload for a color change.
- `RUNOUT_RESUME`: recover from runout or finish an M600 change.
- `TOGGLE_HEAT_SOAK`: toggle the saved five-minute heat soak.
- `HEAT_SOAK_STATUS`: display its current state.
- `G29`: home and create an adaptive runtime mesh.
- `M420`: manually load the saved default mesh.
- `BED_PID_TUNE TEMP=60`: tune and save bed PID values.
- `NOZZLE_PID_TUNE TEMP=230`: tune and save hotend PID values.
- `MAINTENANCE_STATUS`: display print and service counters.

The supplied Pro configuration has no verified bed-screw coordinates, so
automatic screw tramming is intentionally omitted.

## 8. Troubleshooting

If Klipper cannot connect to `CB1`, confirm `/tmp/klipper_host_mcu` exists and
the Pad 7 host MCU service is working. If any configuration error remains,
restore the backup before moving or heating the printer.

Read `FEATURE_GUIDE.md` for advanced parameters and `CREDITS.md` for package
attribution.
