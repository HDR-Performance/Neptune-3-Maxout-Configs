# Files to archive only after successful testing

Keep the supplied working Neptune 3 Pro configuration and a full Mainsail
backup until the HDR Performance package has completed all first tests and at
least one small print.

Afterward, inactive root-level copies of these legacy KAMP files may be moved
to an archive folder if no active include references them:

- `Adaptive_Meshing.cfg`
- `Line_Purge.cfg`
- `Smart_Park.cfg`
- `OG.Line_Purge.cfg`

Do not archive or delete active host files such as `moonraker.conf`,
`KlipperScreen.conf`, or an installed `timelapse.cfg`.
