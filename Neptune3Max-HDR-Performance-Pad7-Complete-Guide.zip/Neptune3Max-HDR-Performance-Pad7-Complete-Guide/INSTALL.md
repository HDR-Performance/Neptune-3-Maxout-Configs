# Install the Neptune 3 Max Robin Nano feature package

This package targets the **ZNP Robin Nano DW v2.2** board. Its hardware pins,
axis geometry, heater configuration, saved Z offset, PID values, input shaper,
and saved mesh come from the supplied `Good Working Robin Nano printer.cfg`.

The ZIP contains a `config` folder. Copy the **contents** of that folder into
Mainsail's existing `/config` directory.

## Before copying

1. Download a fresh full configuration backup from Mainsail.
2. Do not delete or replace `moonraker.conf`, `mainsail.cfg`, `timelapse.cfg`,
   `KlipperScreen.conf`, `sonar.conf`, or the updater-managed `KAMP/` folder.
3. Confirm this printer is using the Robin Nano board. Do not install this
   `printer.cfg` on the SKR 3 EZ board.

## Copy

Copy the **contents** of the packaged `config` folder into `/config`. Allow it
to replace only `printer.cfg` and `KAMP_Settings.cfg`. It adds:

```text
custom/kamp/Adaptive_Meshing.cfg
custom/kamp/Line_Purge.cfg
custom/kamp/Smart_Park.cfg
custom/macros/bed_heat_soak.cfg
custom/macros/filament_control.cfg
custom/macros/maintenance.cfg
custom/macros/material_profiles.cfg
custom/macros/persistent_state.cfg
custom/macros/z_offset_calibration.cfg
custom/state/
archive/
```

The old root-level copies of `Adaptive_Meshing.cfg`, `Line_Purge.cfg`, and
`Smart_Park.cfg` are no longer loaded. Leave them in place until testing is
complete, then archive them if desired.

## Required KAMP settings

Moonraker must contain:

```ini
[file_manager]
enable_object_processing: True
```

In OrcaSlicer, enable **Label objects**. A suitable start command is:

```gcode
M117
START_PRINT BED_TEMP=[bed_temperature_initial_layer_single] EXTRUDER_TEMP=[nozzle_temperature_initial_layer] MATERIAL=PETG
```

Use `END_PRINT` as the slicer end command.

## Restart and first tests

1. Select **Save & Restart**. Do not move the printer if Klipper reports an
   error.
2. Home with `G28`.
3. Run `SMART_PARK`. Z must lift first; XY is capped at 100 mm/s.
4. Heat the nozzle and run `LINE_PURGE`. It should print a 75 mm purge line
   using 30 mm of filament, then wipe and lift.
5. Run `MANUAL_Z_OFFSET_ADJUST` and verify the Mainsail TESTZ adjustment panel
   appears after the nozzle-cleaning sequence.
6. Print a small center-bed test with `SOAK_MINUTES=0` while ready to use
   Emergency Stop.

After the basic tests, follow `FEATURE_GUIDE.md` and test each additional
feature individually.

## Manual Z-offset adjustment

1. Press **MANUAL Z OFFSET ADJUST**. The parameter dialog supports `TEMP`
   (default 230 C) and `PURGE_AMOUNT` (default 30 mm). The bed remains off.
2. The printer reports the loaded saved offset, clears the mesh, fully homes,
   purges and wipes along the left edge, parks at the calibration center, and
   turns off the nozzle heater.
3. A delayed `PROBE_CALIBRATE` opens Mainsail's TESTZ panel immediately; it
   does not wait for the nozzle to cool.
4. Use the positive and negative TESTZ steps with a paper test.
5. Press **ACCEPT**, then run **SAVE_CONFIG**.
6. Klipper writes the new `probe.z_offset`, restarts, and the next calibration
   reads the newly saved value automatically.

Do not manually move to the numeric saved probe offset. A probe Z offset is
the measured trigger-to-nozzle distance, not an absolute machine Z position.
