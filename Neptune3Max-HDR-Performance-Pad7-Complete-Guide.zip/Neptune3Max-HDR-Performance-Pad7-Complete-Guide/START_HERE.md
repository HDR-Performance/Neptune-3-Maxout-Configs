# Neptune 3 Max installation and usage guide

HDR Performance package for the Elegoo Neptune 3 Max with a Robin Nano
controller and BTT Pad 7. This package contains Max-specific limits, mesh,
homing, screw positions, and hotend settings. Never install it on another model.

## 1. Back up and verify

1. Download a complete backup from Mainsail **Machine**.
2. Preserve `printer.cfg`, `moonraker.conf`, `mainsail.cfg`, `timelapse.cfg`,
   `KlipperScreen.conf`, and the updater-managed `KAMP/` directory.
3. Confirm the printer is a Neptune 3 Max with the Robin Nano board, not the
   custom SKR controller version.
4. Confirm `/tmp/klipper_host_mcu` exists on the BTT Pad 7.

## 2. Install

1. Open the ZIP and then its `config` folder.
2. Upload the **contents** of `config` into Mainsail's active `/config` folder.
3. Replace only `printer.cfg` and `KAMP_Settings.cfg`, and upload the complete
   `custom/` folder.
4. Do not replace the host-service files or updater-managed `KAMP/` folder.
5. Select **Save & Restart**. Stop if Klipper reports an error.

Moonraker must contain:

```ini
[file_manager]
enable_object_processing: True
```

## 3. OrcaSlicer setup

Enable **Label objects**. Machine start G-code:

```gcode
M117
START_PRINT BED_TEMP=[bed_temperature_initial_layer_single] EXTRUDER_TEMP=[nozzle_temperature_initial_layer] MATERIAL=PETG
```

Machine end G-code:

```gcode
END_PRINT
```

Change `MATERIAL` to `PLA`, `PETG`, or `TPU`. Remove duplicate slicer commands
for homing, meshing, and purging.

## 4. First-test order

1. Confirm room-temperature heater readings look reasonable.
2. Run `G28` and watch the Max-specific homing sequence closely.
3. Run `SMART_PARK`; Z must lift before XY movement.
4. Heat the nozzle and run `LINE_PURGE`; it must stay inside the bed.
5. Run `ACCELEROMETER_QUERY` and confirm live values appear.
6. Print a small object at the center with `SOAK_MINUTES=0`.

Keep a hand near Emergency Stop throughout initial testing.

## 5. Input shaper

Secure the Pad 7 accelerometer firmly to the toolhead and run
`CALIBRATE_SHAPER`. It homes, measures both axes at X215 Y215 Z20, saves the
recommended shaper settings, and restarts Klipper. Keep clear while the large
bed and toolhead vibrate.

## 6. Bed tramming

Run `MANUAL_BED_TRAMMING`. The macro probes the center reference and six
verified Max screw positions. Follow the displayed turn directions, then rerun
the macro until the adjustments are acceptably small. Tram before final Z
offset calibration and meshing.

## 7. Z-offset adjustment

Run `MANUAL_Z_OFFSET_ADJUST TEMP=230 PURGE_AMOUNT=30`. The bed remains off.
The machine homes, cleans the nozzle along the left, turns the heater off,
returns to the Max calibration position, and opens Mainsail TESTZ controls.
Use paper, press **ACCEPT**, then run `SAVE_CONFIG`.

## 8. Daily features

- `SET_MATERIAL MATERIAL=PETG`: persistent material selection.
- `LOAD_FILAMENT` and `UNLOAD_FILAMENT`: guided filament handling.
- `M600` followed by `RUNOUT_RESUME`: guided color change.
- `RUNOUT_RESUME`: complete runout recovery and resume safely.
- `TOGGLE_HEAT_SOAK`: toggle the saved five-minute bed stabilization.
- `HEAT_SOAK_STATUS`: report the saved state.
- `G29`: home and create an adaptive runtime mesh.
- `M420`: manually load the saved mesh.
- `BED_PID_TUNE TEMP=60`: tune and save bed PID values.
- `NOZZLE_PID_TUNE TEMP=230`: tune and save hotend PID values.
- `MAINTENANCE_STATUS`: display print and service counters.

The Max bed benefits most from heat soak. Leave it off for initial motion tests,
then enable it with `TOGGLE_HEAT_SOAK` after confirming the workflow.

## 9. Troubleshooting

If Klipper reports a `CB1` error, verify the Pad 7 host MCU and
`/tmp/klipper_host_mcu`. Do not move or heat the printer while configuration
errors exist. Restore the backup if required.

See `FEATURE_GUIDE.md` for detailed macro options.
