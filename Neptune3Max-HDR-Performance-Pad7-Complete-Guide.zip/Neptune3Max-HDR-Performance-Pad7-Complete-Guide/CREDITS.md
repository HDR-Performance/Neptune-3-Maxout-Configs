# HDR Performance

**Neptune 3 Max Robin Nano + BTT Pad 7 upgrade package by HDR Performance.**

Package integration, safety-oriented macros, adaptive meshing and purge,
filament recovery, material profiles, Z-offset workflow, heat-soak controls,
maintenance counters, and this installation guide are credited to HDR
Performance.

Klipper and Klipper Adaptive Meshing & Purging retain their respective
authorship and licenses.
