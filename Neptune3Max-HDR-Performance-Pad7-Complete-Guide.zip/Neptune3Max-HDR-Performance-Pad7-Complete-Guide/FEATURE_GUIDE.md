# Neptune 3 Max Robin Nano feature guide

This guide covers the organized user-facing features in the Robin Nano
package. Hardware pins and electrical settings remain in `printer.cfg`.

## Safe KAMP start and purge

`START_PRINT` heats the nozzle only to a 150 C standby temperature before
homing and meshing. `SMART_PARK` lifts Z before XY travel and caps XY at
100 mm/s. Final nozzle heating occurs after the mesh.

`LINE_PURGE` separates line length from filament amount: it lays a 75 mm line
using 30 mm of filament at a calculated 14 mm3/s flow rate. Its coordinates
are clamped inside the configured travel range, and it lifts before every long
XY move.

## Filament controls

### LOAD_FILAMENT

Heats to the selected material's saved load temperature, feeds 70 mm, purges
10 mm, retracts slightly, and turns the heater off. Optional parameters:

```gcode
LOAD_FILAMENT TEMP=220 LOAD=70 PURGE=10 KEEP_HOT=0
```

### UNLOAD_FILAMENT

Heats, primes briefly, forms a retracting tip, unloads 70 mm, and turns the
heater off:

```gcode
UNLOAD_FILAMENT TEMP=220 UNLOAD=70 KEEP_HOT=0
```

### M600 color change

During a print, **M600** pauses, parks, preserves the printing temperature, and
unloads the filament. Insert the replacement filament and press **RUNOUT
RESUME**. That control verifies the filament sensor, reheats if necessary,
loads, purges, and resumes the print.

## Filament-runout recovery

The filament sensor now invokes the same guided recovery workflow. During a
runout it pauses and parks without immediately unloading broken filament. If
the pause lasts ten minutes, the hotend heater switches off. Inserting filament
restores the saved target and begins a fresh ten-minute safety window. **RUNOUT
RESUME** cancels the timer, waits for the saved temperature, completes loading,
and resumes. If Resume is never pressed, the reheated hotend switches off again.

Normal **RESUME** is blocked while runout recovery is active so the printer
cannot resume without filament.

## Bed heat soak

Automatic heat soak is off by default. Press **TOGGLE HEAT SOAK** to turn it on
or off; the selection persists across restarts. **HEAT SOAK STATUS** reports the
current setting without changing it.

When enabled, `START_PRINT` waits for the bed sensor to reach `BED_TEMP`, holds
that temperature for `SOAK_MINUTES`, and only then runs KAMP. The default soak
duration is five minutes. This allows the large aluminum bed and build surface
to stabilize before the mesh is measured.

Set the slicer start command as desired:

```gcode
START_PRINT BED_TEMP=60 EXTRUDER_TEMP=210 SOAK_MINUTES=5 MATERIAL=PLA
```

Use `SOAK=1` or `SOAK=0` to override the saved toggle for one print. Use
`SOAK_MINUTES=0` to skip the delay. The standalone control is:

```gcode
BED_HEAT_SOAK BED_TEMP=60 MINUTES=5
```

## Material and pressure-advance profiles

Select a profile with:

```gcode
SET_MATERIAL MATERIAL=PLA
SET_MATERIAL MATERIAL=PETG
SET_MATERIAL MATERIAL=TPU
```

The selected material persists across restarts and is applied automatically by
`START_PRINT`. Initial pressure-advance values are PLA `0.056`, PETG `0.056`,
and TPU `0.020`. These are starting values and should be calibrated for the
actual filament and toolhead.

Save calibrated values with:

```gcode
SAVE_MATERIAL_PROFILE MATERIAL=PLA PA=0.056 LOAD_TEMP=220
```

## Maintenance counters

Every successful `END_PRINT` records completed-print count, print hours, and
hours since nozzle, lubrication, and belt service.

Use **MAINTENANCE STATUS** to display the values. Reset a service counter with:

```gcode
MAINTENANCE_RESET ITEM=NOZZLE
MAINTENANCE_RESET ITEM=LUBRICATION
MAINTENANCE_RESET ITEM=BELTS
MAINTENANCE_RESET ITEM=ALL
```

Cancelled prints are not added to the counters.

## First-test order

1. Restart Klipper and resolve configuration errors before moving anything.
2. Select the correct material with `SET_MATERIAL`.
3. Test `LOAD_FILAMENT` and `UNLOAD_FILAMENT` while idle.
4. Run `BED_HEAT_SOAK BED_TEMP=40 MINUTES=0.1` as a short functional test.
5. Start a small test print with `SOAK_MINUTES=0`.
6. During that test, use `M600`, insert filament, and press `RUNOUT_RESUME`.
7. Complete the print and check `MAINTENANCE_STATUS`.

Keep a hand near Emergency Stop during every first physical test.
