# Neptune 3 standard — HDR Performance SKR 3 EZ Maxout build

This package converts the standard Elegoo Neptune 3 geometry and stock Bowden extrusion values to an SKR 3 EZ with TMC5160 Pro EZ drivers and a BTT Pad 7. It includes the full HDR Performance macro suite and KAMP layout.

## Important strain-gauge limitation

The standard Neptune 3 uses a nozzle-contact strain-gauge leveling system, unlike the inductive probe on the Pro, Plus, and Max. The configuration assigns its probe signal to the SKR dedicated PROBE input, PC13, but the stock toolhead-interface harness is not electrically documented by the SKR pinout. Verify signal voltage, ground, and connector pin order before connecting it. This package is an engineering conversion build, not a plug-and-play harness claim.

## Model baseline

- Configured travel: X 0–235, Y 0–235, Z -2–280 mm
- Safe Z position: X110 Y110
- Mesh: 20,20 to 200,200; 4×4 base grid
- Stock-style Bowden extruder rotation distance: 24 mm
- Hotend safety limit: 250 °C
- Strain-gauge probe: PC13 after interface verification
- Filament motion sensor: PC2
- Both Z motors: one TMC5160 driver through the proven shared harness
- Maxout motors: 42×60 mm / 2.1 A Y motor and the original Y motor moved to X

## Install

1. Read `WIRING_AND_FIRMWARE.md` completely and verify every electrical connection.
2. Back up the entire current `~/printer_data/config` directory.
3. Build and flash firmware for the exact H723/H743 chip on the SKR.
4. Copy the contents of this package's `config` directory into `~/printer_data/config`, preserving the folders. `printer.cfg` must remain in the config root.
5. Replace the MCU placeholder in `printer.cfg` with the result of `ls /dev/serial/by-id/`.
6. Perform the controlled tests in `WIRING_AND_FIRMWARE.md`. Do not home until PC13 probe state and both endstops have been proven manually.
7. Calibrate PID, Z offset, mesh, extrusion rotation distance, pressure advance, and input shaper.
8. Add only the two lines in `SLICER_GCODE.md` to the slicer.

Use `FEATURE_GUIDE.md` for the friendly controls and `TROUBLESHOOTING.md` if a validation step fails.

