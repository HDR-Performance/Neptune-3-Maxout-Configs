# Neptune 3 Pro — HDR Performance SKR 3 EZ Maxout build

This package combines the supplied working Neptune 3 Pro geometry with the HDR Performance SKR 3 EZ, TMC5160 Pro EZ, upgraded-motor, BTT Pad 7, KAMP, and macro baseline.

## Model baseline

- Configured travel: X -6–235, Y 0–235, Z -2–280 mm
- Safe Z position: X117.5 Y117.5
- Mesh: 30,30 to 205,205; 6×6 base grid
- Direct-drive extruder rotation distance: 6.9 mm
- Stock hotend safety limit: 250 °C
- Inductive probe: PC0 through Z-STOP, offset X-28 Y20
- Filament switch: PC2
- Both Z motors: one TMC5160 driver through the proven shared harness
- Maxout motors: 42×60 mm / 2.1 A Y motor and the original Y motor moved to X

## Install

1. Read `WIRING_AND_FIRMWARE.md` completely. Verify heater, fan, probe, sensor, and motor pin order rather than relying on connector shape.
2. Back up the entire current `~/printer_data/config` directory.
3. Build and flash firmware for the exact H723/H743 chip on the SKR.
4. Copy the contents of this package's `config` directory into `~/printer_data/config`, preserving the folders. `printer.cfg` belongs in the root.
5. Replace the MCU placeholder with the result of `ls /dev/serial/by-id/`.
6. Perform every controlled first-power test before the first home.
7. Calibrate PID, Z offset, bed mesh, extrusion rotation distance, pressure advance, and input shaper.
8. Add only the start and end macro calls in `SLICER_GCODE.md` to the slicer.

The 250 °C limit is deliberate for the stock hotend. If a different all-metal hotend is installed, confirm its exact thermistor model and rating before changing `sensor_type` or `max_temp`.

