# HDR Performance Neptune 3 Plus + BTT Pad 7 upgrade package

Upgrade package by **HDR Performance** for the **Elegoo Neptune 3 Plus** with
the **ZNP Robin Nano DW v2.2** controller.

The Neptune 3 Plus has an approximately 320 x 320 x 400 mm printable build
area. This package uses the supplied config's slightly larger 330 mm XY motion
envelope and 410 mm Z motion limit, along with its hardware pins,
heater PID values, probe offset, saved Z offset, input-shaper values, mesh
bounds, and screw locations from the supplied working Neptune 3 Plus config.

## Before copying

1. Download a fresh full configuration backup from Mainsail.
2. Do not delete or overwrite `moonraker.conf`, `KlipperScreen.conf`,
   `sonar.conf`, or any other host-service configuration.
3. Confirm the printer is a Neptune 3 Plus using a Robin Nano board. This
   package is not for a Neptune 3 Max or an SKR controller.
4. Confirm `/tmp/klipper_host_mcu` exists on the BTT Pad 7 before restarting
   Klipper; the included ADXL345 configuration requires it.

## Install

Copy the **contents** of the ZIP's `config` folder into the printer's active
configuration directory. Allow it to replace `printer.cfg` and
`KAMP_Settings.cfg`. It adds the organized `custom/` directory.

Do not copy a Max `printer.cfg` onto this printer. The Plus uses different
travel, mesh, safe-home, screw, and Z-height values.

The supplied source had timelapse disabled, so this package leaves the line
below commented in `printer.cfg`:

```ini
#[include timelapse.cfg]
```

Only uncomment it if `timelapse.cfg` is already installed and working.

## Required KAMP settings

Moonraker must contain:

```ini
[file_manager]
enable_object_processing: True
```

Enable **Label objects** in OrcaSlicer. Example start G-code:

```gcode
M117
START_PRINT BED_TEMP=[bed_temperature_initial_layer_single] EXTRUDER_TEMP=[nozzle_temperature_initial_layer] MATERIAL=PETG
```

Use this as the end G-code:

```gcode
END_PRINT
```

Change `MATERIAL=PETG` to PLA or TPU when appropriate.

## First-test order

1. Select **Save & Restart**. If Klipper reports an error, do not move or heat
   the printer.
2. Run `HDR_PACKAGE_INFO` and confirm the Plus package credit is displayed.
3. Home with `G28`. Safe Z homing should occur at X160 Y160.
4. Run `SMART_PARK`. Z must lift before XY travel, and XY is capped at
   100 mm/s.
5. Heat the nozzle and run `LINE_PURGE`. It should lay a 75 mm purge line using
   30 mm of filament, then wipe and lift.
6. Run `MANUAL_BED_TRAMMING` and verify the six Plus screw locations.
7. Run `MANUAL_Z_OFFSET_ADJUST`; verify the left-side clean, return to X160
   Y160, and Mainsail TESTZ controls.
8. Print a small center-bed model with `SOAK_MINUTES=0` while ready to use
   Emergency Stop.

## Manual Z-offset workflow

`MANUAL_Z_OFFSET_ADJUST TEMP=230 PURGE_AMOUNT=30` keeps the bed heater off,
homes, cleans the nozzle along the left side, turns the nozzle heater off, and
immediately starts `PROBE_CALIBRATE` at the Plus safe-home position. Use the
Mainsail TESTZ controls, press **ACCEPT**, then run **SAVE_CONFIG**. The next
calibration reads the newly saved offset automatically.

## Input shaper

The supplied starting values are preserved: Y uses MZV at 38.2 Hz and X uses
EI at 79.6 Hz. The included Pad 7 setup uses `/tmp/klipper_host_mcu`, the
onboard ADXL345 on `spidev1.1`, and `axes_map: z,y,-x`, matching the HDR
Performance Maxout setup. Confirm `ACCELEROMETER_QUERY` returns values, secure
the accelerometer to the toolhead, then run `CALIBRATE_SHAPER`. The macro homes,
calibrates both axes at X160 Y160 Z20, and saves the results.
