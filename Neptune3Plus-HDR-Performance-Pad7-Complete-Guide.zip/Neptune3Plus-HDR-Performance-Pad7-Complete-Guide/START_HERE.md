# Neptune 3 Plus installation and usage guide

HDR Performance package for the Elegoo Neptune 3 Plus with a Robin Nano
controller and BTT Pad 7. Do not install it on the standard, Pro, or Max.

## 1. Back up and verify

1. Download a complete configuration backup from Mainsail **Machine**.
2. Preserve `printer.cfg`, all host-service files, and the updater-managed
   `KAMP/` directory.
3. Confirm this is the Plus model with the Robin Nano board.
4. Confirm `/tmp/klipper_host_mcu` exists on the BTT Pad 7.

## 2. Install

1. Open the ZIP and its `config` folder.
2. Upload the **contents** of `config` to Mainsail's active `/config` folder.
3. Replace `printer.cfg` and `KAMP_Settings.cfg`, and upload the entire
   `custom/` directory.
4. Do not replace `moonraker.conf`, `mainsail.cfg`, `KlipperScreen.conf`,
   `timelapse.cfg`, or `KAMP/`.
5. Select **Save & Restart** and stop if Klipper reports an error.

Moonraker requires:

```ini
[file_manager]
enable_object_processing: True
```

## 3. OrcaSlicer setup

Enable **Label objects** and use:

```gcode
M117
START_PRINT BED_TEMP=[bed_temperature_initial_layer_single] EXTRUDER_TEMP=[nozzle_temperature_initial_layer] MATERIAL=PETG
```

Use `END_PRINT` for machine end G-code. Change `MATERIAL` to `PLA`, `PETG`, or
`TPU`. Remove duplicate slicer homing, mesh, and purge commands.

## 4. First-test order

1. Run `HDR_PACKAGE_INFO` and confirm the Plus package is identified.
2. Check that room-temperature heater readings are reasonable.
3. Run `G28`; safe Z homing should occur near X160 Y160.
4. Run `SMART_PARK` and confirm Z lifts first.
5. Heat the nozzle and run `LINE_PURGE`; it must stay inside the bed.
6. Run `ACCELEROMETER_QUERY` and confirm live values.
7. Print a small center-bed object with `SOAK_MINUTES=0`.

Keep a hand near Emergency Stop during these checks.

## 5. Input shaper

Secure the Pad 7 accelerometer to the toolhead, then run
`CALIBRATE_SHAPER`. It homes, measures both axes at X160 Y160 Z20, saves the
results, and restarts Klipper. Keep clear during the vibration test.

## 6. Bed tramming

Run `MANUAL_BED_TRAMMING`. Klipper probes the six verified Plus screw
locations. Adjust the screws using the displayed turn directions and repeat
until the reported adjustment is acceptably small. Run this before the final
Z-offset calibration and mesh.

## 7. Z-offset adjustment

Run `MANUAL_Z_OFFSET_ADJUST TEMP=230 PURGE_AMOUNT=30`. The bed stays off while
the printer homes, cleans the nozzle along the left, switches the heater off,
returns to X160 Y160, and opens TESTZ. Adjust with paper, press **ACCEPT**, and
run `SAVE_CONFIG`.

## 8. Daily features

- `SET_MATERIAL MATERIAL=PETG`: select a persistent profile.
- `LOAD_FILAMENT` and `UNLOAD_FILAMENT`: guided loading and unloading.
- `M600` followed by `RUNOUT_RESUME`: guided color change.
- `RUNOUT_RESUME`: finish filament-runout recovery.
- `TOGGLE_HEAT_SOAK`: toggle the saved five-minute pre-mesh soak.
- `HEAT_SOAK_STATUS`: report its state.
- `G29`: home and create an adaptive runtime mesh.
- `M420`: load the saved default mesh manually.
- `BED_PID_TUNE TEMP=60` and `NOZZLE_PID_TUNE TEMP=230`: PID tuning.
- `MAINTENANCE_STATUS`: print and service counters.

## 9. Troubleshooting

A `CB1` connection error usually means `/tmp/klipper_host_mcu` is unavailable.
Do not move or heat the machine while configuration errors are present. Restore
the backup if needed.

See `FEATURE_GUIDE.md` for advanced parameters and `CREDITS.md` for package
attribution.
