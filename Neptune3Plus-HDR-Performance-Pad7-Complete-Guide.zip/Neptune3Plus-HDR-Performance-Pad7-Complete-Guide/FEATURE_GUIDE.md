# HDR Performance Neptune 3 Plus feature guide

This upgrade package is designed and credited to **HDR Performance**.

## Safe KAMP workflow

`START_PRINT` heats the nozzle only to a maximum 150 C standby temperature
before homing and adaptive meshing. `SMART_PARK` lifts Z first and caps XY
travel at 100 mm/s. The nozzle reaches final printing temperature only after
the KAMP mesh is complete.

`LINE_PURGE` separates line length from extrusion amount. It produces a 75 mm
line using 30 mm of filament at a calculated 14 mm3/s. Coordinates are bounded
for the Neptune 3 Plus motion envelope.

## Filament controls

`LOAD_FILAMENT` and `UNLOAD_FILAMENT` use the active material's saved loading
temperature. The Plus hotend is limited dynamically to the configured maximum.

```gcode
LOAD_FILAMENT TEMP=220 LOAD=70 PURGE=10 KEEP_HOT=0
UNLOAD_FILAMENT TEMP=220 UNLOAD=70 KEEP_HOT=0
```

During a print, `M600` pauses, parks, remembers the print temperature, and
unloads filament. Insert replacement filament and run `RUNOUT_RESUME`.

## Runout recovery and safety cooldown

The filament sensor starts the guided runout workflow. Normal `RESUME` is
blocked until filament is detected and `RUNOUT_RESUME` is used. If the printer
waits for ten minutes, the hotend switches off. Filament insertion reheats to
the saved target and starts a fresh ten-minute safety window.

## Optional bed heat soak

Automatic heat soak is off by default. `TOGGLE_HEAT_SOAK` changes the saved
setting and `HEAT_SOAK_STATUS` reports it. When enabled, `START_PRINT` waits for
the bed to reach target and stabilizes it for five minutes before KAMP.

```gcode
START_PRINT BED_TEMP=60 EXTRUDER_TEMP=210 SOAK_MINUTES=5 MATERIAL=PLA
```

Use `SOAK=0` or `SOAK=1` for a one-print override.

## Material and pressure-advance profiles

```gcode
SET_MATERIAL MATERIAL=PLA
SET_MATERIAL MATERIAL=PETG
SET_MATERIAL MATERIAL=TPU
SAVE_MATERIAL_PROFILE MATERIAL=PETG PA=0.056 LOAD_TEMP=240
```

The selected material and calibrated loading values persist across restarts.
The provided pressure-advance values are starting points and require printing
calibration for the actual filament.

## Maintenance counters

Successful `END_PRINT` calls record print count, print hours, and service hours.

```gcode
MAINTENANCE_STATUS
MAINTENANCE_RESET ITEM=NOZZLE
MAINTENANCE_RESET ITEM=LUBRICATION
MAINTENANCE_RESET ITEM=BELTS
MAINTENANCE_RESET ITEM=ALL
```

Cancelled prints are not counted as completed.

## Additional controls

- `HDR_PACKAGE_INFO`: display HDR Performance package credit.
- `MANUAL_BED_TRAMMING`: probe all six Plus bed screws.
- `MANUAL_Z_OFFSET_ADJUST`: clean the nozzle and open the TESTZ workflow.
- `BED_PID_TUNE`: tune the bed heater within configured limits.
- `CALIBRATE_SHAPER`: calibrate both axes with the Pad 7 ADXL345 and save.
- `NOZZLE_PID_TUNE`: tune the hotend within its configured 250 C limit.
- `SET_FAN_SPEED`: set part cooling, with optional persistent override.
- `G29`: home and generate a runtime adaptive mesh.
- `M420`: load the saved default mesh manually.
