# Neptune 3 Plus — HDR Performance SKR 3 EZ Maxout build

This package combines the supplied working Neptune 3 Plus geometry with the HDR Performance SKR 3 EZ, TMC5160 Pro EZ, upgraded-motor, BTT Pad 7, KAMP, and macro baseline.

## Model baseline

- Configured travel: X -8.3–330, Y -1.3–330, Z 0–410 mm
- Safe Z position: X160 Y160
- Mesh: 22,22 to 290,315; 7×7 base grid
- Direct-drive extruder rotation distance: 6.9 mm
- Stock hotend safety limit: 250 °C
- Inductive probe: PC0 through Z-STOP, offset X-28.5 Y22
- Filament switch: PC2
- Both Z motors: one TMC5160 driver through the proven shared harness
- Maxout motors: 42×60 mm / 2.1 A Y motor and the original Y motor moved to X

## Install

1. Read `WIRING_AND_FIRMWARE.md` completely. Check the bed's current before connecting it to the SKR BED output; use a correctly rated external MOSFET when required.
2. Back up the entire current `~/printer_data/config` directory.
3. Build and flash firmware for the exact H723/H743 chip on the SKR.
4. Copy the contents of this package's `config` directory into `~/printer_data/config`, preserving the folders. `printer.cfg` belongs in the root.
5. Replace the MCU placeholder with the result of `ls /dev/serial/by-id/`.
6. Perform every controlled first-power test before the first home.
7. Calibrate PID, Z offset, screw tilt, mesh, extrusion rotation distance, pressure advance, and input shaper.
8. Add only the start and end macro calls in `SLICER_GCODE.md` to the slicer.

The 250 °C limit is deliberate for the stock hotend. Verify the exact thermistor and rating before enabling a different hotend.

